setwd("C:\\Users\\User\\Desktop\\IT24104309")

# Question 01
# 01
# Binomial Distribution
# Random variable X has a Binominal Distribuion with n=50 and p=0.85

# 02
dbinom(47, 50, 0.85)

# Question 02
# 01 
# Number of customer calls received on a given hour

# 02
# Poisson Distribution
# Random Variable X has a Poisson Distribution with lamda=12

# 03
dpois(15, 12)