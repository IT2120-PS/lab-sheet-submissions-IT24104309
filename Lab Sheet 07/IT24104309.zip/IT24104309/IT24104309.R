setwd("C:\\Users\\User\\Desktop\\IT24104309")

# Question 01
# X - uniform distribution with a=0 and b=40
# P(10 <= X <= 25)
punif(25, min=0, max=40, lower.tail= FALSE) - punif(10, min=0, max=40, lower.tail=TRUE)

# Question 02
# X - Exponential Distribution with lamda=0.34
pexp(2, rate = 0.34, lower.tail=TRUE)

# Question 03 
1-pnorm(130, mean=100, sd=15, lower.tail=TRUE)

qnorm(0.95, mean=100, sd=15, lower.tail=FALSE)